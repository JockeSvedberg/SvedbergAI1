# SvedbergAI - AI-driven affärsautomation SaaS

Automatisera din vardag med AI-assistenter för småföretag. Bokningsbot, chatbot och e-postautomation i ett paket.

## 🚀 Snabbstart

### 1. Klona och installera
bash
git klon <ditt-förråd>
cd svedbergai
npm-installation
2. Konfigurera miljövariabler
våldsamt slag
Kopiera
cp .env.example .env.local
 # Fyll i dina API-nyckel i .env.local
3. Kör lokalt
våldsamt slag
Kopiera
npm kör dev
Öppna http://localhost:3000

📦 Utplacera till Vercel
Automatisk distribution
Skicka koden till GitHub
Gå till vercel.com och logga in
Klicka på "Nytt projekt" → välj ditt repo
Vercel känner av Next.js automatiskt
Lägg till miljövariabler i Vercels instrumentpanel
Utplacera! 🚀
Manuell driftsättning
våldsamt slag
Kopiera
npm install -g vercel
Vercel --prod
🗄️ Databasinställning (Supabase)
1. Skapa Supabase-projektet
Gå till supabase.com
Skapa nytt projekt
Kopiera URL och API-nyckel till.env.local
2. Kör databasschema
sql
Kopiera
-- Kör innehåll från backend/schema.sql i Supabase SQL Editor
3. Konfigurera autentisering
Gå till Autentisering → Inställningar
Aktivera e-postautentisering
Lägg till din domän i "Site URL"
💳 Randig uppsättning
1. Produkter
Du har redan skapat produkter i Stripe:

Basic: 199 kr/månad
Fördel: 499 kr/månad
Premium: 999 kr/månad
2. Webhooks
Gå till Stripe Dashboard → Webhooks
Lägg till slutpunkt:https://svedbergai.se/api/stripe-webhook
Välj evenemang:
checkout.session.completed
customer.subscription.updated
customer.subscription.deleted
Kopiera webhook hemlig till.env.local
🔗 Installation av Google API:er
1. Google Cloud-konsolen
Gå till console.cloud.google.com
Skapa nytt projekt eller valt befintligt
Aktivera API:er:
Google Kalender API
Gmail API
2. OAuth-autentiseringsuppgifter
Gå till Inloggningsuppgifter → Skapa inloggningsuppgifter → OAuth-klient-ID
Applikationstyp: Webbapplikation
Auktoriserade omdirigerings-URI:er:
https://svedbergai.se/api/auth/callback
http://localhost:3000/api/auth/callback
3. Servicekonto
Skapa inloggningsuppgifter → Servicekonto
Ladda ner JSON-nyckelfil
Kopiera client_emailoch private_keytill.env.local
📧 Gmail Setup för Outreach
1. Applösenord
Gå till Google-konto → Säkerhet
Aktivera tvåstegsverifiering
Generera applösenord för "Mail"
Använd detta lösenord iGMAIL_APP_PASSWORD
2. Körs uppsökande bot
våldsamt slag
Kopiera
cd -uppsökande
python cold_email_bot.py
🛠️ Funktionär
✅ Färgglatt
🌐 Landningssida med hjälte, inslag, CTA
💳 Prissättning med Stripe Checkout
📊 Dashboard med bokningar och widget-kod
💬 Bokningswidget (popup med tider)
🔐 Logga in/Registrera dig (Supabase-autentisering)
📧 Cold email bot med AI-genererade mejl
🔄 Nästa steg (lägg till API-nyckel)
✅ Integrering med Google Kalender
✅ Gmail automatiska bekräftelser
✅ Stripe webhook-hantering
✅ Supabase databaskoppling
📁 Projektstruktur
svedbergai/
├── pages/                 # Next.js sidor
│   ├── index.tsx         # Landningssida
│   ├── pricing.tsx       # Prissida
│   ├── dashboard.tsx     # Kundportal
│   ├── login.tsx         # Inloggning
│   └── signup.tsx        # Registrering
├── components/           # React komponenter
│   └── BookingWidget.tsx # Bokningswidget
├── backend/              # Backend funktioner
│   ├── functions/        # Supabase Edge Functions
│   └── schema.sql        # Databas schema
├── outreach/             # Marknadsföring
│   └── cold_email_bot.py # AI email bot
└── utils/                # Hjälpfunktioner
    └── supabaseClient.ts # Supabase klient
🎯 Användning
För dig (admin)
Logga in på instrumentpanelen
Kopiera widgetkod
Klistra på din hemsida
Kunder kan nu boka direkt!
För kunder
Ser bokningsknapp på din hemsida
Klicka → välj tid
Får bekräftelse via mejl
Påminnelse dygnet runt
🔧 Anpassning
Ändra färg
Redigera tailwind.config.js:

js
Kopiera
tema : {
   extend : {
     färger : {
       primär : '#2563EB' , // Din huvudfärg 
      sekundär : '#1E40AF' ,
    }
  }
}
Lägg till flera tjänster
Redigera components/BookingWidget.tsxoch lägg till fler alternativ.

📞 Stöd
📧 support@svedbergai.se
💬 Chatta med AI-support på hemsidan
📚 Dokumentation: docs.svedbergai.se
📈 Nästa steg
Lägg till API-nyckel → aktivera alla funktioner
Anpassa design → logga, färger, texter
Testa bokningsflödet → från widget till kalender
Starta marknadsföring → kör outreach bot
Skala upp → lägga till fler funktioner
Lycka till med SvedbergAI! 🚀
