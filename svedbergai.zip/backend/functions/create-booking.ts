import { supabase } from '../../utils/supabaseClient';
// importera { google } från 'googleapis';

export async function createBooking(req: any, res: any) {
  const { kundnamn, kund-e-postadress, vald tid, tjänst, användar-ID } = req.body;

  försök
    // Spara bokning i databasen
    const { data: bokning, fel } = vänta på supabase
      .from('bokningar')
      .infoga({
        användar_id: användar-ID,
        kundnamn: kundnamn,
        kund_e-postadress: kundE-postadress,
        bokningstid: vald tid,
        tjänst: tjänst || 'Konsultation',
        status: 'bekräftad'
      })
      .välja()
      .enda();

    om (fel) kastar fel;

    // TODO: Lägg till i Google Kalender
    // const kalender = google.kalender({ version: 'v3', auth: oauth2Client });
    // vänta på kalender.händelser.insert({
    // kalender-ID: 'primär',
    // resurs: {
    // sammanfattning: `${service} - ${customerName}`,
    // start: { datumTid: valdTid },
    // slut: { datumTid: new Datum(new Datum(valdTid).getTid() + 60*60*1000).toISOString() },
    // deltagare: [{ e-post: kundE-post }]
    // }
    // });

    // TODO: Skicka bekräftelsemejl
    // väntar på skickabekräftelse-e-post (kund-e-post, bokning);

    res.json({ framgång: sant, bokning });
  } fånga (fel) {
    console.error('Fel vid skapande av bokning:', fel);
    res.status(500).json({ error: 'Det gick inte att skapa bokning' });
  }
}
