importera Stripe från 'stripe';
importera { supabase } från '../../utils/supabaseClient';

const stripe = new Stripe(process.miljö.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
});

exportera async-funktionen handleStripeWebhook(req: any, res: any) {
  const sig = req.headers['stripe-signature'];
  låt händelse: Stripe.Händelse;

  försök
    händelse = stripe.webhooks.constructEvent(
      req.body,
      sign!,
      process.miljö.STRIPE_WEBHOOK_SECRET!
    );
  } fånga (fel) {
    console.log('Verifiering av webhook-signatur misslyckades.', err);
    returnera res.status(400).send(`Webhook-fel: ${(err as Error).message}`);
  }

  // Hantera händelsen
  switch (händelse.typ) {
    ärende 'checkout.session.avslutad':
      const session = event.data.object som Stripe.Checkout.Session;
      
      // Skapa eller uppdatera användarprenumeration
      vänta på supabase.from('prenumerationer').upsert({
        stripe_customer_id: session.customer som sträng,
        stripe_subscription_id: session.prenumeration som sträng,
        status: 'aktiv',
        plannamn: session.metadata?.plan || 'grundläggande',
        current_period_end: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 dagars provperiod
      });

      console.log('Prenumeration skapad:', session.id);
      bryta;

    ärende 'kund.prenumeration.uppdaterad':
      const uppdateradSub = event.data.object som Stripe.Prenumeration;
      
      vänta på supabase
        .from('prenumerationer')
        .uppdatera({
          status: uppdateradSub.status,
          nuvarande_period_slut: nytt datum(uppdateradSub.nuvarande_period_slut * 1000),
        })
        .eq('stripe_prenumerations_id', uppdateradSub.id);

      console.log('Prenumeration uppdaterad:', updatedSub.id);
      bryta;

    ärende 'kund.prenumeration.borttagen':
      const borttagenSub = event.data.object som Stripe.Prenumeration;
      
      vänta på supabase
        .from('prenumerationer')
        .uppdatera({ status: 'avbruten' })
        .eq('stripe_prenumerations_id', borttagenSub.id);

      console.log('Prenumeration avbruten:', borttagenSub.id);
      bryta;

    standard:
      console.log(`Ohanterad händelsetyp ${event.type}`);
  }

  res.json({ mottagen: sant });
}
