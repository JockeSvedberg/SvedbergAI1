-- Användartabell
SKAPA TABELL användare (
  id UUID DEFAULT gen_random_uuid() PRIMÄRNYCKEL,
  e-post VARCHAR(255) UNIK INTE NULL,
  namn VARCHAR(255) INTE NULL,
  företaget VARCHAR(255),
  created_at TIDSTÄMPEL MED STANDARD TIDZON NU(),
  uppdaterad_vid TIDSSTÄMPEL MED STANDARDINSTÄLLNING FÖR TIDSZON NU()
);

-- Prenumerationstabell
SKAPA TABELL-prenumerationer (
  id UUID DEFAULT gen_random_uuid() PRIMÄRNYCKEL,
  användar-id UUID-REFERENSER användare(id) VID RADERA CASCADE,
  stripe_customer_id VARCHAR(255) UNIK,
  stripe_prenumerations_id VARCHAR(255) UNIK,
  status VARCHAR(50) INTE NULL STANDARD 'trial', -- trial, aktiv, avbruten, förfallen
  plannamn VARCHAR(50) INTE NULL STANDARD 'grundläggande', -- grundläggande, pro, premium
  aktuell_period_slut TIDSTÄMPEL MED TIDSZON,
  created_at TIDSTÄMPEL MED STANDARD TIDZON NU(),
  uppdaterad_vid TIDSSTÄMPEL MED STANDARDINSTÄLLNING FÖR TIDSZON NU()
);

-- Bokningstabell
SKAPA BORDBOKNINGAR (
  id UUID DEFAULT gen_random_uuid() PRIMÄRNYCKEL,
  användar-id UUID-REFERENSER användare(id) VID RADERA CASCADE,
  kundnamn VARCHAR(255) INTE NULL,
  kund_e-post VARCHAR(255) INTE NULL,
  kund_telefon VARCHAR(50),
  bokningstid TIDSTÄMPEL MED TIDSZON INTE NULL,
  tjänst VARCHAR(255) DEFAULT 'Konsultation',
  status VARCHAR(50) NOT NULL DEFAULT 'bekräftad', -- bekräftad, avbruten, slutförd
  anteckningar TEXT,
  created_at TIDSTÄMPEL MED STANDARD TIDZON NU(),
  uppdaterad_vid TIDSSTÄMPEL MED STANDARDINSTÄLLNING FÖR TIDSZON NU()
);

-- Bottabell (för att lagra botkonfigurationer per användare)
SKAPA TABELL-botar (
  id UUID DEFAULT gen_random_uuid() PRIMÄRNYCKEL,
  användar-id UUID-REFERENSER användare(id) VID RADERA CASCADE,
  bot_type VARCHAR(50) NOT NULL, -- bokning, chatt, e-post
  namn VARCHAR(255) INTE NULL,
  konfiguration JSONB INTE NULL STANDARD '{}',
  är_aktiv BOOLESKT STANDARD sant,
  created_at TIDSTÄMPEL MED STANDARD TIDZON NU(),
  uppdaterad_vid TIDSSTÄMPEL MED STANDARDINSTÄLLNING FÖR TIDSZON NU()
);

-- Index för bättre prestanda
SKAPA INDEX idx_prenumerationer_användar_id PÅ prenumerationer(användar_id);
SKAPA INDEX idx_subscriptions_stripe_customer PÅ prenumerationer(stripe_customer_id);
SKAPA INDEX idx_bookings_user_id PÅ bookings(user_id);
SKAPA INDEX idx_bookings_time PÅ bookings(booking_time);
SKAPA INDEX idx_bots_user_id PÅ bots(user_id);
