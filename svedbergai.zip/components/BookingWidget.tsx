import { useState } from "react";

exportera standardfunktionen BookingWidget() {
  const [steg, setStep] = useState<"idle" | "formulär" | "klar">("idle");
  const [valdTid, angeValdTid] = useState("");

  konstant tillgängligaTider = [
    "27 aug 14:00",
    "28 aug 10:00", 
    "28 aug 15:30",
    "29 aug 09:00",
    "29 aug 16:00"
  ];

  const handbokning = (tid: sträng) => {
    setValdTid(tid);
    setStep("klar");
    // TODO: Skicka bokning till backend
    console.log("Bokning gjord för:", tid);
  };

  om (steg === "tomgång") {
    återvända (
      <knapp
        onClick={() => setStep("formulär")}
        className="fast botten-6 höger-6 bg-primär text-vit px-6 py-3 rundad-full skugga-lg hover:bg-blå-700 övergång-alla hover:skala-105 z-50"
      >
        💬 Boka tid
      </knapp>
    );
  }

  om (steg === "formulär") {
    återvända (
      <div className="fast botten-6 höger-6 b-80 bg-vit skugga-2xl rundad-lg p-6 z-50 kant">
        <div className="flex justify-mellan-objekt-center mb-4">
          <h3 className="text-lg font-semibold">Välj en tid</h3>
          <knapp 
            onClick={() => setStep("inaktiv")}
            className="text-grå-400 hovring:text-grå-600"
          >
            ✕
          </knapp>
        </div>
        
        <div className="mellanslag-y-2 mb-4">
          {tillgängligaTider.karta((tid) => (
            <knapp
              nyckel={tid}
              onClick={() => handleBooking(tid)}
              className="w-full text-left px-4 py-3 border rounded-lg hover:bg-blue-50 hover:border-primary transition"
            >
              <div className="font-medium">{tid</div>
              <div className="text-sm text-gray-600">Ledig</div>
            </knapp>
          ))}
        </div>

        <div className="text-xs text-grå-500 text-center">
          Drivs av SvedbergAI
        </div>
      </div>
    );
  }

  om (steg === "klart") {
    återvända (
      <div className="fast botten-6 höger-6 w-80 bg-grön-50 kant kant-grön-300 rundad-lg p-6 skugga-2xl z-50">
        <div className="textcenter">
          <div className="text-2xl mb-2">✅</div>
          <h3 className="text-lg font-semibold text-green-800 mb-2">Bokning bekräftad!</h3>
          <p className="text-green-700 mb-2">
            Din tid: <strong>{selectedTime}</strong>
          </p>
          <p className="text-sm text-grön-600 mb-4">
            Du får en bekräftelse via e-post inom kort.
          </p>
          <knapp
            onClick={() => setStep("inaktiv")}
            className="text-sm text-primär understrykning hovring:ingen-understrykning"
          >
            Stäng
          </knapp>
        </div>
      </div>
    );
  }

  returnera null;
}
