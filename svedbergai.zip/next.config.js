/** @type {import('next').NextConfig} */
const nästaKonfiguration = {
  reactStrictMode: sant,
  swcMinify: sant,
}

modul.exports = nästaKonfiguration
