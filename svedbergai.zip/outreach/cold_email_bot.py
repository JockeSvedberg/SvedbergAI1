#!/usr/bin/env python3
""""
SvedbergAI Bot för kall e-postutskick
Genererar personliga e-postmeddelanden med hjälp av AI och skickar via Gmail API
""""

importera operativsystem
importera csv
importera json
importtid
från datetime import datetime
importförfrågningar
från email.mime.text importera MIMEText
från email.mime.multipart importera MIMEMultipart
importera smtplib

klass ColdEmailBot:
    def __init__(själv):
        self.gmail_user = os.getenv('GMAIL_USER')
        self.gmail_password = os.getenv('GMAIL_APP_PASSWORD') # Använd applösenord
        self.routellm_api_key = os.getenv('ROUTELLM_API_KEY')
        
    def generate_personalized_email(själv, företagsnamn, bransch, plats):
        \ ...
        
        prompt = f"""
        Skriv ett kort, personligt och professionellt mejl på svenska till {company_name} i {location}.
        
        Företaget verkar vara inom {industry}.
        
        Mejlet ska:
        - Vara max 100 ord
        - Nämna deras bransch och ort
        - Förklara hur SvedbergAI kan hjälpa dem automatisera bokningar
        - Ha en vanlig uppmaning till handling
        - Låta personligt, inte som spam
        
        Ämnesrad: [ÄMNE]
        Mejltext: [TEXT]
        """
        
        försök:
            svar = requests.post(
                'https://api.abacus.ai/v1/chat/completions',
                rubriker={
                    'Auktorisering': f'Bärare {self.routellm_api_key}',
                    'Innehållstyp': 'applikation/json'
                },
                json={
                    'modell': 'gpt-4o-mini',
                    'meddelanden': [{'roll': 'användare', 'innehåll': prompt}],
                    'max_tokens': 300
                }
            )
            
            om svar.statuskod == 200:
                innehåll = response.json()['val'][0]['meddelande']['innehåll']
                
                # Extrahera ämne och brödtext
                rader = innehåll.split('\n')
                ämne = ""
                kropp = ""
                
                för rad i rader:
                    om line.startswith('Ämnesrad:') eller line.startswith('[ÄMNE]'):
                        ämne = line.split(':', 1)[1].strip() if ':' in line else line.replace('[ÄMNE]', '').strip()
                    elif line.startswith('Mejltext:') eller line.startswith('[TEXT]'):
                        body = line.split(':', 1)[1].strip() om ':' i rad annars line.replace('[TEXT]', '').strip()
                    elif-kropp och line.strip():
                        kropp += '\n' + linje.remsa()
                
                återvända
                    'subject': subject eller f'Automatisera bokningar för {company_name}',
                    'kropp': kropp eller innehåll
                }
                
        förutom Undantag som e:
            print(f'Fel vid generering av e-post: {e}')
            
        # Reservmall
        återvända
            'subject': f'Automatisera bokningar för {company_name}',
            'kropp': f"""Hej!

Jag såg att {company_name} i {location} verkar vara inom {industry}. 

Vi hjälper företag som är att automatisera med AI - så att slipper svara i telefon och kan hållas på det ni gör bäst.

Intresserad av en 5-minuters demo?

Mvh,
Anna Svedberg
SvedbergAI.se"""
        }
    
    def skicka_epost(själv, till_epost, ämne, brödtext, företagsnamn):
        ""Skicka e-post via Gmail SMTP""
        
        försök:
            msg = MIMEMultipart()
            msg['Från'] = self.gmail_user
            msg['Till'] = till_e-post
            msg['Ämne'] = ämne
            
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(self.gmail_user, self.gmail_password)
            
            text = msg.as_string()
            server.sendmail(self.gmail_user, till_e-post, text)
            server.quit()
            
            print(f'✅ E-post skickat till {company_name} ({to_email})')
            returnera Sant
            
        förutom Undantag som e:
            print(f'❌ Misslyckades med att skicka e-post till {company_name}: {e}')
            returnera Falskt
    
    def process_leads_from_csv(self, csv_file, max_emails=20):
        \ ...
        
        skickat_antal = 0
        
        försök:
            med open(csv_file, 'r', encoding='utf-8') som fil:
                läsare = csv.DictReader(fil)
                
                för rad i läsaren:
                    om skickat_antal >= max_e-postmeddelanden:
                        bryta
                        
                    företagsnamn = rad.get('företagsnamn', '')
                    e-post = rad.get('e-post', '')
                    industri = row.get('industri', 'småföretag')
                    plats = rad.get('plats', 'Sverige')
                    
                    om inte företagsnamn eller inte e-postadress:
                        fortsätta
                    
                    print(f'Genererar e-post för {company_name}...')
                    
                    # Skapa personligt e-postmeddelande
                    email_content = self.generate_personalized_email(
                        företagsnamn, bransch, plats
                    )
                    
                    # Skicka e-post
                    om self.send_email(
                        e-post, 
                        email_content['ämne'], 
                        email_content['body'],
                        företagsnamn
                    ):
                        skickat_antal += 1
                        
                        # Logga skickat e-postmeddelande
                        med open('sent_emails.log', 'a', encoding='utf-8') som logg:
                            log.write(f'{datetime.now()},{company_name},{email},sent\n')
                    
                    # Hastighetsbegränsning
                    tid.sömn(2)
                    
        förutom Undantag som e:
            print(f'Fel vid bearbetning av CSV: {e}')
        
        print(f'\n📧 Skickade {sent_count} e-postmeddelanden totalt')

om __namn__ == '__huvud__':
    bot = ColdEmailBot()
    
    # Exempel på användning:
    # bot.process_leads_from_csv('leads.csv', max_emails=10)
    
    skriva ut("""
    SvedbergAI Kall e-postbot
    
    Installation:
    1. Skapa leads.csv med kolumnerna: företagsnamn, e-postadress, bransch, plats
    2. Ställ in miljövariabler:
       - GMAIL_USER=din-e-postadress@gmail.com
       - GMAIL_APP_PASSWORD=ditt-app-lösenord
       - ROUTELLM_API_KEY=din-API-nyckel
    3. Kör: python cold_email_bot.py
    """)
