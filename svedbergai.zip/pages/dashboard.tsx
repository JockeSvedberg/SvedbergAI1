import { useState, useEffect } från "react";
importera länk från "nästa/länk";

exportera standardfunktionen Dashboard() {
  const [användare, setUser] = useState({ namn: "Anna Svedberg", e-post: "anna@svedbergai.se", plan: "Pro" });
  const [bokningar, setBokningar] = useState([
    { id: 1, kund: "Maria Andersson", tid: "2025-08-27 14:00", tjänst: "Massage", status: "Bekräftad" },
    { id: 2, kund: "Johan Lindqvist", tid: "2025-08-28 10:00", tjänst: "Konsultation", status: "Bekräftad" },
    { id: 3, kund: "Emma Karlsson", tid: "2025-08-29 16:00", tjänst: "Behandling", status: "Väntande" },
  ]);

  const widgetKod = `<script src="https://svedbergai.se/widget.js" data-användare="användare_123"></script>`;

  återvända (
    <div className="bg-gray-50 min-h-screen">
      {/* Navigering */}
      <nav className="bg-vit skugga-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-mellan-objekt-center">
          <Länk href="/" className="text-2xl font-bold text-primary">SvedbergAI</Länk>
          <div className="mellanslag-x-4">
            <span className="text-gray-600">Hej, {användarnamn</span>
            <button className="text-gray-600 hover:text-primary">Logga ut</button>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Rubrik */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Välkommen tillbaka, {user.name}!</h1>
          <div className="flexobjekt-centerutrymme-x-4">
            <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
              Plan: {användare.plan} (Aktiv)
            </span>
            <span className="text-gray-600">Nästa betalning: 25 sep 2025</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Huvudinnehåll */}
          <div className="lg:col-span-2 space-y-6">
            {/* Statistik */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-vit p-6 rundad-xl skugga-sm">
                <div className="text-2xl font-bold text-primary">{bookings.length}/div>
                <div className="text-gray-600">Bokningar denna vecka</div>
              </div>
              <div className="bg-vit p-6 rundad-xl skugga-sm">
                <div className="text-2xl font-bold text-green-600">94%</div>
                <div className="text-gray-600">Automatiserad hantering</div>
              </div>
              <div className="bg-vit p-6 rundad-xl skugga-sm">
                <div className="text-2xl font-bold text-blue-600">2,5 timmar</div>
                <div className="text-gray-600">Sparad tid per dag</div>
              </div>
            </div>

            {/* Nyligen genomförda bokningar */}
            <div className="bg-vit rundad-xl skugga-sm">
              <div className="p-6 border-b">
                <h2 className="text-xl font-semibold">Senaste bokningar</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {bokningar.karta((bokning) => (
                    <div key={booking.id} className="flexibla objekt-center justify-between p-4 border rounded-lg">
                      <div>
                        <div className="font-semibold">{bokning.kund}}}}}
                        <div className="text-gray-600">{bokningstjänst}}}}}
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">{bokningstid}/div>
                        <span className={`px-2 py-1 avrundad-fulltext-xs typsnitt-halvfet ${
                          booking.status === 'Bekräftad' 
                            ? 'bg-grön-100 text-grön-800' 
                            : 'bg-gul-100 text-gul-800'
                        }`}>
                          {bokningsstatus}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Sidofält */}
          <div className="space-y-6">
            {/* Widgetkod */}
            <div className="bg-vit rundad-xl skugga-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Din widget-kod</h3>
              <p className="text-gray-600 text-sm mb-4">Kopiera och klistra i denna kod på din hemsida:</p>
              <div className="bg-gray-100 p-3 rounded-lg">
                <code className="text-sm break-all">{widgetCode}</code>
              </div>
              <knapp 
                onClick={() => navigator.urklipp.skrivText(widgetkod)}
                className="mt-3 w-full bg-primär text-vit py-2 px-4 avrundad-lg hover:bg-blå-700 övergång"
              >
                Kopieringskod
              </knapp>
            </div>

            {/* Snabbåtgärder */}
            <div className="bg-vit rundad-xl skugga-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Snabbåtgärder</h3>
              <div className="mellanslag-y-3">
                <button className="w-full text-left p-3 border rounded-lg hover:bg-gray-50 transition">
                  📅 Hantera kalender
                </knapp>
                <button className="w-full text-left p-3 border rounded-lg hover:bg-gray-50 transition">
                  💬 Anpassa chatbot
                </knapp>
                <button className="w-full text-left p-3 border rounded-lg hover:bg-gray-50 transition">
                  📧 E-postinställningar
                </knapp>
                <Länk href="/prissättning">
                  <button className="w-full text-left p-3 border rounded-lg hover:bg-gray-50 transition">
                    ⬆️ Uppgradera planen
                  </knapp>
                </Länk>
              </div>
            </div>

            {/* Stöd */}
            <div className="bg-blue-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-2">Behöver du hjälp?</h3>
              <p className="text-gray-600 text-sm mb-4">Vår AI-support svarar 24/7</p>
              <button className="w-full bg-primary text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition">
                Chatta med-support
              </knapp>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
