importera länk från "next/link";
importera BookingWidget från "../components/BookingWidget";

exportera standardfunktionen Home() {
  återvända (
    <div className="bg-gray-50 min-h-screen">
      {/* Navigering */}
      <nav className="bg-vit skugga-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-mellan-objekt-center">
          SvedbergAI
          <div className="mellanslag-x-4">
            <Länk href="/pricing" className="text-gray-600 hover:text-primary">Prisare</Länk>
            <Länk href="/login" className="text-gray-600 hover:text-primary">Logga in</Länk>
            <Länk href="/signup" className="bg-primary text-white px-4 py-2 rounded-lg">Kom igen</Länk>
          </div>
        </div>
      </nav>

      {/* Hjälteavsnitt */}
      <section className="text-center py-20 bg-gradient-till-r från-primär till-blå-400 text-vit">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-5xl font-bold mb-6">SvedbergAI</h1>
          <p className="text-xl mb-4">
            Automatisera din vardag – låt AI boka, svara & följa upp åt dig.
          </p>
          <p className="text-lg mb-8 opacitet-90">
            För småföretagare som vill ha fler kunder och mer tid. Enkelt, smart och prisvärt.
          </p>
          <div className="mellanslag-x-4">
            <Länk href="/prissättning">
              <button className="px-8 py-3 bg-vit text-primärt font-halvfet rundad-lg skugga-md hovring:skugga-lg övergång">
                Testa gratis i 14 dagar
              </knapp>
            </Länk>
            <Länk href="#demo">
              <button className="px-8 py-3 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-primary transition">
                Se demo
              </knapp>
            </Länk>
          </div>
        </div>
      </avsnitt>

      {/* Funktioner */}
      <section className="py-16 max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Allt du behöver för att automatisera</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="p-6 bg-vit rundad-xl skugga-md text-center">
            <div className="text-4xl mb-4">📅</div>
            <h3 className="text-xl font-semibold mb-2">Bokningsbot</h3>
            <p className="text-gray-600">Släpp telefonsamtalen – kunder bokar direkt i din kalender. Automatiska påminnelser och bekräftelser.</p>
          </div>
          <div className="p-6 bg-vit rundad-xl skugga-md text-center">
            <div className="text-4xl mb-4">💬</div>
            <h3 className="text-xl font-semibold mb-2">Chatbot</h3>
            <p className="text-gray-600">Svarar automatiskt på vanliga frågor & fångar leder 24/7. Anpassad för din bransch.</p>
          </div>
          <div className="p-6 bg-vit rundad-xl skugga-md text-center">
            <div className="text-4xl mb-4">📧</div>
            <h3 className="text-xl font-semibold mb-2">E-postautomation</h3>
            <p className="text-gray-600">Skicka påminnelser, tackmejl och kampanjer automatiskt. Bygg relationer medan du sover.</p>
          </div>
        </div>
      </avsnitt>

      {/* Demosektion */}
      <section id="demo" className="py-16 bg-gray-100">
        <div className="max-w-4xl mx-auto px-4 textcenter">
          <h2 className="text-3xl font-bold mb-8">Se hur enkelt det är</h2>
          <div className="bg-vit rundad-xl skugga-lg p-8">
            <p className="text-lg mb-4">Testa bokningswidgeten här nedan:</p>
            <div className="relativ h-64 bg-grå-50 rundad-lg flex objekt-center justera-center">
              <p className="text-gray-500">Din hemsida här...</p>
            </div>
          </div>
        </div>
      </avsnitt>

      {/* Uppmaning till uppmaning */}
      <section className="py-16 text-center bg-primär text-vit">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold mb-4">Gör om att spara tid och få fler kunder?</h2>
          <p className="text-xl mb-8">Börja idag – ingen bindningstid, avslutad när du vill.</p>
          <Länk href="/prissättning">
            <button className="px-10 py-4 bg-vit text-primär text-lg font-semibold avrundad-lg shadow-lg hover:shadow-xl övergång">
              Välj din plan
            </knapp>
          </Länk>
        </div>
      </avsnitt>

      {/* Sidfot */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-6xl mx-auto px-4 textcenter">
          <div className="text-xl font-bold mb-4">SvedbergAI</div>
          <p className="text-gray-400">Automatisera din vardag med AI</p>
          <div className="mt-4 mellanslag-x-4">
            <a href="mailto:support@svedbergai.se" className="text-gray-400 hover:text-white">support@svedbergai.se</a>
          </div>
        </div>
      </sidfot>

      {/* Bokningswidget */}
      <Bokningswidget />
    </div>
  );
}
