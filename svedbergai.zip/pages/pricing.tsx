importera länk från "next/link";

exportera standardfunktionen Prissättning() {
  konstant planer = [
    {
      namn: "Grundläggande",
      pris: "199 kr/månad",
      funktioner: ["Bokningsbot", "Google Calendar integration", "E-postbekräftelser", "Grundläggande support"],
      cta: "Välj Basic",
      länk: "https://buy.stripe.com/9B64gsebIgqBawJ6kVaZi00",
      populär: falsk
    },
    {
      namn: "Proffs",
      pris: "499 kr/månad",
      funktioner: ["Allt i Basic", "Chatbot med AI", "Anpassade svar", "Prioriterad support", "Statistik & rapporter"],
      cta: "Välj Pro",
      länk: "https://buy.stripe.com/aFadR20kSfmxcER8t3aZi01",
      populär: sant
    },
    {
      namn: "Premium",
      pris: "999 kr/månad",
      funktioner: ["Allt i Pro", "E-postautomation", "Kampanjverktyg", "Avancerad AI", "Dedikerad support", "White-label"],
      cta: "Välj Premium",
      länk: "https://buy.stripe.com/14A3co0kS0rD0W9dNnaZi02",
      populär: falsk
    }
  ];

  återvända (
    <div className="bg-gray-50 min-h-screen">
      {/* Navigering */}
      <nav className="bg-vit skugga-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-mellan-objekt-center">
          <Länk href="/" className="text-2xl font-bold text-primary">SvedbergAI</Länk>
          <div className="mellanslag-x-4">
            <Länk href="/" className="text-gray-600 hover:text-primary">Fåll</Länk>
            <Länk href="/login" className="text-gray-600 hover:text-primary">Logga in</Länk>
          </div>
        </div>
      </nav>

      {/* Rubrik */}
      <section className="text-center py-16">
        <h1 className="text-4xl font-bold mb-4">Välj din plan</h1>
        <p className="text-xl text-gray-600 mb-8">14 dagars gratis testperiod. Ingen bindningstid.</p>
      </avsnitt>

      {/* Priskort */}
      <section className="max-w-6xl mx-auto px-4 pb-16">
        <div className="grid md:grid-cols-3 gap-8">
          {planer.karta((plan, index) => (
            <div key={index} className={`bg-vit rundad-xl skugga-lg p-8 text-center relativ ${plan.populär ? 'border-2 border-primary' : ''}`}>
              {plan.populär && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-white px-4 py-1 rounded-full text-sm font-semibold">Populärt</span>
                </div>
              )}
              <h2 className="text-2xl font-bold mb-2">{plan.namn}</h2>
              <div className="text-3xl font-bold text-primary mb-6">{plan.pris}/div>
              <ul className="text-vänster mellanslag-y-3 mb-8">
                {plan.funktioner.karta((funktion, i) => (
                  <li key={i} className="flex-artikelcenter">
                    <span className="text-green-500 mr-2">✓</span>
                    {särdrag}
                  </li>
                ))}
              </ul>
              <a href={plan.link} target="_blank" rel="noopener noreferrer">
                <button className={`w-full py-3 px-6 rounded-lg font-semibold transition ${
                  plan.populär 
                    ? 'bg-primär text-vit hovring:bg-blå-700' 
                    : 'bg-grå-100 text-grå-800 hovra:bg-grå-200'
                }`}>
                  {plan.cta}
                </knapp>
              </a>
            </div>
          ))}
        </div>
      </avsnitt>

      {/* Vanliga frågor */}
      <section className="bg-vit py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Vanliga frågor</h2>
          <div className="space-y-6">
            <div className="border-b pb-4">
              <h3 className="text-lg font-semibold mb-2">Hur snabbt kan jag komma igång?</h3>
              <p className="text-gray-600">Du kan vara igång på under 5 minuter. Registrera dig, välj plan och få din widget-kod direkt.</p>
            </div>
            <div className="border-b pb-4">
              <h3 className="text-lg font-semibold mb-2">Kan jag avsluta när som helst?</h3>
              <p className="text-gray-600">Ja, ingen bindningstid. Du kan avsluta din prenumeration när som helst från din dashboard.</p>
            </div>
            <div className="border-b pb-4">
              <h3 className="text-lg font-semibold mb-2">Fungerar det med min befintliga hemsida?</h3>
              <p className="text-gray-600">Ja, vår widget fungerar med alla hemsidor. Du klistrar bara in en kod-rad.</p>
            </div>
          </div>
        </div>
      </avsnitt>
    </div>
  );
}
