import { useState } from "react";
importera länk från "nästa/länk";

exportera standardfunktionen Signup() {
  const [formData, setFormData] = useState({
    namn: "",
    e-post: "",
    lösenord: "",
    företag: ""
  });

  const handleSignup = (e: React.FormEvent) => {
    e.preventStandard();
    // TODO: Implementera Supabase-autentisering
    console.log("Registrering:", formulärData);
    // Omdirigera till prissättning för demo
    fönster.plats.href = "/prissättning";
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formulärData,
      [e.mål.namn]: e.mål.värde
    });
  };

  återvända (
    <div className="bg-gray-50 min-h-screen flex items-center justify-center">
      <div className="max-w-md w-full bg-vit rundad-xl shadow-lg p-8">
        <div className="text-center mb-8">
          <Länk href="/" className="text-2xl font-bold text-primary">SvedbergAI</Länk>
          <h2 className="mt-4 text-xl font-semibold">Skapa ditt konto</h2>
          <p className="text-gray-600 mt-2">14 dagars gratis testperiod</p>
        </div>

        <form onSubmit={handleSignup} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Namn
            </etikett>
            <inmatning
              typ="text"
              namn="namn"
              värde={formulärData.namn}
              vidÄndring={handtagÄndring}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg fokus:outline-none fokus:ring-2 fokus:ring-primary"
              nödvändig
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              E-postadress
            </etikett>
            <inmatning
              typ="e-post"
              namn="e-post"
              värde={formulärData.e-post}
              vidÄndring={handtagÄndring}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg fokus:outline-none fokus:ring-2 fokus:ring-primary"
              nödvändig
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Företag (valfritt)
            </etikett>
            <inmatning
              typ="text"
              namn="företag"
              värde={formulärData.företag}
              vidÄndring={handtagÄndring}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg fokus:outline-none fokus:ring-2 fokus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Lösenord
            </etikett>
            <inmatning
              typ="lösenord"
              namn="lösenord"
              värde={formulärData.lösenord}
              vidÄndring={handtagÄndring}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg fokus:outline-none fokus:ring-2 fokus:ring-primary"
              nödvändig
            />
          </div>

          <knapp
            typ="skicka"
            className="w-full bg-primary text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition font-semibold"
          >
            Skapa konto
          </knapp>
        </formulär>

        <div className="mt-6 textcenter">
          <p className="text-gray-600">
            Har du skrivit ett konto?
            <Länk href="/login" className="text-primary hover:underline">
              Logga in här
            </Länk>
          </p>
        </div>
      </div>
    </div>
  );
}
