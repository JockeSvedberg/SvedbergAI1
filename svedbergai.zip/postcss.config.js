module.exports = {
  insticksprogram: {
    medvindcss: {},
    autoprefix: {},
  },
}
