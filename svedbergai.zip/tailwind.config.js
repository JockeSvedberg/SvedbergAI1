/** @type {import('tailwindcss').Config} */
modul.export = {
  innehåll: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './komponenter/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  tema: {
    förläng: {
      färger: {
        primär: '#2563EB',
        sekundär: '#1E40AF',
      }
    },
  },
  insticksprogram: [],
}
